
// export const SERVICES_URL = 'http://186.154.240.180:8098/api/';
// //export const SERVICES_URL = 'http://localhost/Nogalapi/api/';
//
// //export const SERVICES_URL = 'http://132.147.157.88/Nogalapi/api/';
 //export const appCentralizacionUrl = "http://132.147.157.88/centralizacion/api/";
 export const appCentralizacionUrl = "http://consultoria.digitalware.co/seven_crm/centralizacion/api/";
// const appCentralizacionUrl = "http://186.154.240.181/centralizacion/api/";
export const appVersion:string = '19.0.4.0';
export const appCopyright = 'SEVEN-ERP © 1992 - 2019';
export const appGooglePlayUrl = "https://play.google.com/store/apps/details?id=com.digitalware.com.co.seven.reservas";
export const appAppStoreUrl = "https://itunes.apple.com/us/app/seven-reservas/id1426063835?l=es&ls=1&mt=8";
export const developer = 'DigitalWare Team';
export const developerMail = 'soporte@digitalware.com.co';
export const developerFacebook = 'https://www.facebook.com/digitalware/';
export const developerTwitter = 'https://twitter.com/Digital_Ware';
export const developerWeb = 'http://www.digitalware.com.co/';
